sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("bosch.po.managepo.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);